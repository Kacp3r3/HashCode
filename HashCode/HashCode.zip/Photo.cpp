#include "Photo.h"

Photo::~Photo()
{
}
