#include "SlideMaker.h"


SlideMaker::~SlideMaker()
{
}
